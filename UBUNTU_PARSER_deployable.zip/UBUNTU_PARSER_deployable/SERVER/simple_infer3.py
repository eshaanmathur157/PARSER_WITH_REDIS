import psycopg2
import pandas as pd
import torch
import torch.nn as nn
import numpy as np
import warnings
import sys
import redis
import requests
import json
import time
import joblib  # <<< ADDED: To load the saved scalers

# Suppress warnings
warnings.filterwarnings('ignore')

# ==============================================================================
# --- ⚙️ CONFIGURATION ---
# ==============================================================================
DB_CONFIG = {
    "host": "localhost",
    "port": "4566",
    "user": "root",
    "dbname": "dev"
}
REDIS_HOST = '20.46.50.39'
REDIS_PORT = 6379
KEY_PAIR_TO_BASE = "PAIR_TO_BASE_VAULT" 
RESULTS_FILE = "inference_results.json"  # <<< NEW: File to save results
# --- PATHS ---
MODEL_PATH = "/home/proxy1/UBUNTUPARSER/SERVER/discriminator_t3_2.pth"
SCALER_PATH = "/home/proxy1/UBUNTUPARSER/SERVER/scalers_t3.pkl"

SEQ_LEN = 3
NUM_FEATURES = 17
HIDDEN_DIM = 64 
THRESHOLD = 0.5 

# --- CRITICAL: This must match the order in column_order.json from training ---
FEATURE_ORDER = [
    "aggregated_buy_volume_usd", "aggregated_sell_volume_usd", "total_volume_usd",
    "max_liquidity", "min_liquidity", "price_max", "price_min",
    "price_delta", "price_std", "buy_price_std", "sell_price_std",
    "number_of_buys", "number_of_sells", "number_of_unique_buyers", "number_of_unique_sellers",
    "buy_perc", "sell_perc"
]

# ==============================================================================
# --- 🧠 MODEL DEFINITION ---
# ==============================================================================
class EnhancedDiscriminator(nn.Module):
    def __init__(self, num_features, hidden_dim, intermediate_dim=32):
        super(EnhancedDiscriminator, self).__init__()
        self.lstm = nn.LSTM(num_features, hidden_dim, num_layers=2, batch_first=True, dropout=0.25)
        self.classification_head = nn.Sequential(
            nn.Linear(hidden_dim * 2, intermediate_dim),
            nn.LeakyReLU(0.2),
            nn.Dropout(0.3),
            nn.Linear(intermediate_dim, 1)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        lstm_out, (h_n, _) = self.lstm(x)
        last_hidden_state = h_n[-1]
        avg_pooled_states = torch.mean(lstm_out, dim=1)
        combined_features = torch.cat((last_hidden_state, avg_pooled_states), dim=1)
        out = self.classification_head(combined_features)
        score = self.sigmoid(out)
        return score

# ==============================================================================
# --- 🛠️ HELPER FUNCTIONS ---
# ==============================================================================

def get_redis_client():
    try:
        r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True)
        r.ping()
        return r
    except Exception as e:
        print(f"✗ Failed to connect to Redis: {e}")
        sys.exit(1)

def build_reverse_map(r_client):
    try:
        standard_map = r_client.hgetall(KEY_PAIR_TO_BASE)
        reverse_map = {v: k for k, v in standard_map.items()}
        print(f"✅ Built reverse map with {len(reverse_map)} entries.")
        return reverse_map
    except Exception as e:
        print(f"⚠️ Failed to build reverse map: {e}")
        return {}

def get_all_base_vaults():
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        query = "SELECT DISTINCT poolIdentifier FROM pool_master_5min;"
        df = pd.read_sql(query, conn)
        conn.close()
        return df['poolidentifier'].tolist() 
    except Exception as e:
        print(f"✗ Failed to fetch pool list: {e}")
        return []

def get_pool_data(base_vault):
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        query = f"""
            SELECT * FROM pool_master_5min
            WHERE poolIdentifier = '{base_vault}'
            ORDER BY time ASC
            LIMIT {SEQ_LEN};
        """
        df = pd.read_sql(query, conn)
        conn.close()
        if len(df) < SEQ_LEN:
            return None
        return df
    except Exception:
        return None

def apply_saved_scalers(df, fitted_scalers):
    try:
        for col in FEATURE_ORDER:
            if col not in df.columns:
                df[col] = 0.0
        
        data_np = df[FEATURE_ORDER].values.astype(np.float32)
        
        if not np.all(np.isfinite(data_np)):
            data_np = np.nan_to_num(data_np, nan=0.0, posinf=1e30, neginf=-1e30)

        scaled_data = data_np.copy()
        for scaler, indices in fitted_scalers:
            scaled_data[:, indices] = scaler.transform(data_np[:, indices])
            
        return scaled_data
    except Exception as e:
        print(f"⚠️ Scaling Error: {e}")
        return None

def prepare_tensor(scaled_np_array):
    if scaled_np_array is None:
        return None
    tensor = torch.tensor(scaled_np_array, dtype=torch.float32)
    tensor = tensor.unsqueeze(0) 
    return tensor

def load_resources():
    model = EnhancedDiscriminator(num_features=NUM_FEATURES, hidden_dim=HIDDEN_DIM)
    try:
        state_dict = torch.load(MODEL_PATH, map_location=torch.device('cpu'))
        model.load_state_dict(state_dict)
        model.eval()
        print("✅ Model loaded successfully.")
    except Exception as e:
        print(f"✗ Error loading model: {e}")
        return None, None

    try:
        scalers = joblib.load(SCALER_PATH)
        print(f"✅ Scalers loaded successfully from {SCALER_PATH}")
    except Exception as e:
        print(f"✗ Error loading scalers: {e}")
        return None, None

    return model, scalers

def fetch_raydium_metadata(pool_addr):
    url = f"https://api-v3.raydium.io/pools/key/ids?ids={pool_addr}"
    try:
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("success") and data.get("data"):
                pool_info = data["data"][0]
                mint_a = pool_info.get("mintA", {})
                mint_b = pool_info.get("mintB", {})
                vaults = pool_info.get("vault", {})
                return {
                    "base_mint": mint_b.get("address"),
                    "base_name": mint_b.get("name"),
                    "base_symbol": mint_b.get("symbol"),
                    "base_logo": mint_b.get("logoURI"),
                    "base_vault": vaults.get("B"),
                    "quote_mint": mint_a.get("address"),
                    "quote_name": mint_a.get("name"),
                    "quote_symbol": mint_a.get("symbol"),
                    "quote_logo": mint_a.get("logoURI"),
                    "quote_vault": vaults.get("A")
                }
    except Exception:
        pass
    return None

# ==============================================================================
# --- 🚀 MAIN EXECUTION ---
# ==============================================================================
if __name__ == "__main__":
    
    print("⏳ Connecting to Redis...")
    r = get_redis_client()
    vault_to_pool_map = build_reverse_map(r)

    print("⏳ Loading Resources...")
    model, fitted_scalers = load_resources()
    if not model or not fitted_scalers:
        sys.exit(1)

    print("🔍 Fetching list of all Base Vaults from DB...")
    base_vaults = get_all_base_vaults()
    print(f"✅ Found {len(base_vaults)} vaults. Starting inference...\n")
    print("-" * 60)

    valid_count = 0
    skipped_count = 0
    rug_pull_count = 0
    safe_pool_count = 0
    
    # <<< ADDED: List to store safe pools >>>
    safe_pool_addresses = []

    for b_vault in base_vaults:
        if not b_vault: continue

        # 1. Get Data
        raw_df = get_pool_data(b_vault)
        
        if raw_df is not None:
            # 2. Apply SAVED Scalers (Transform only)
            scaled_np = apply_saved_scalers(raw_df, fitted_scalers)
            
            # 3. Create Tensor
            input_tensor = prepare_tensor(scaled_np)
            
            if input_tensor is not None:
                # 4. Predict
                with torch.no_grad():
                    prediction = model(input_tensor)
                    score = prediction.item()
                
                is_rug_pull = score > THRESHOLD
                
                # 5. Reverse Lookup
                pool_address = vault_to_pool_map.get(b_vault, None)
                
                if is_rug_pull:
                    rug_pull_count += 1
                else:
                    safe_pool_count += 1
                    # <<< ADDED: Capture SAFE pool address >>>
                    if pool_address:
                        safe_pool_addresses.append(pool_address)
                
                if pool_address:
                    metadata = fetch_raydium_metadata(pool_address)
                    if metadata:
                        result_json = {
                            "pool_address": pool_address,
                            "status": "RUG_PULL" if is_rug_pull else "SAFE",
                            "confidence_score": round(score, 6),
                            "metadata": metadata
                        }
                        with open(RESULTS_FILE, "a") as f:
                            f.write(json.dumps(result_json) + "\n")
                        print(json.dumps(result_json, indent=4))
                        print("-" * 20)
                        valid_count += 1
                        time.sleep(0.2)
                    else:
                        print(f"⚠️ Metadata missing for {pool_address} (Score: {score:.4f})")
                        skipped_count += 1
                else:
                    skipped_count += 1
            else:
                skipped_count += 1
        else:
            skipped_count += 1

    print("-" * 60)
    print(f"✅ Finished.")
    print(f"Processed: {valid_count}")
    print(f"Skipped:   {skipped_count}")
    print("-" * 30)
    print(f"🚨 RUG PULLS DETECTED: {rug_pull_count}")
    print(f"🛡️ SAFE POOLS DETECTED: {safe_pool_count}")
    
    # <<< ADDED: Print safe addresses at the end >>>
    print("\n" + "=" * 40)
    print("💎 SAFE LIQUIDITY POOL ADDRESSES 💎")
    print("=" * 40)
    if safe_pool_addresses:
        for addr in safe_pool_addresses:
            print(addr)
    else:
        print("(None found)")
    print("=" * 40)