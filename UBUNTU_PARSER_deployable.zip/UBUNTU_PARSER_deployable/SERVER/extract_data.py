# ==============================================================================
# db_to_pt_pipeline.py
#
# PURPOSE:
#   1. Connects to Redis to get mapping of Pool Address -> Base Vault.
#   2. Separates pools into "Rug Pulls" (Positive) and "Safe" (Negative).
#   3. Queries RisingWave (Postgres) for the first N minutes of data.
#   4. Saves them as .pt tensors for GAN training.
# ==============================================================================
import os
import torch
import pandas as pd
import numpy as np
import psycopg2
import redis
import random
from tqdm import tqdm
import json

# ==============================================================================
# --- ⚙️ CONFIGURATION ---
# ==============================================================================

# --- Database & Redis ---
DB_CONFIG = {
    "host": "localhost",
    "port": "4566",
    "user": "root",
    "dbname": "dev"
}
REDIS_HOST = '20.46.50.39'
REDIS_PORT = 6379
KEY_PAIR_TO_BASE = "PAIR_TO_BASE_VAULT"

# --- Output Paths ---
OUTPUT_DIR = r"preprocessed_db_v1"

# --- Data Parameters ---
NUM_FEATURES = 17
TRAIN_SET_SIZE_RUGS = 0.8 # 80% of rug pulls for training
RANDOM_SEED = 42

# --- Safe Pools (Non-Rug Pulls) ---
# These are the ONLY pools considered "Safe" (Negative Class)
SAFE_POOL_ADDRESSES = [
    "EiYQw9zcNdS5DWHnkotZckwVY2wkpAw7B6QqR6kLnAjP",
    "GaPTvXuog95vxJii7qwvfNVNdpgAcEmjFqYdZnxxgzLV",
    "4FVtkkAnERE792WCVsDBvLAm6257E6JFSNRC73rmM5k6",
    "VaZdKwBr7bg8ciYGM9rkoBZgfJZbGJWXQBJTbdjYpgu",
    "7vfvqKBSVnYGMg8AsnJzJRmGUGyJcxGK4YwfphNTSYgP"
]

# --- Feature Order (CRITICAL: Must match training script expectation) ---
# Based on your SQL schema provided
FEATURE_ORDER = [
    "aggregated_buy_volume_usd", "aggregated_sell_volume_usd", "total_volume_usd",
    "max_liquidity", "min_liquidity", "price_max", "price_min",
    "price_delta", "price_std", "buy_price_std", "sell_price_std",
    "number_of_buys", "number_of_sells", "number_of_unique_buyers", "number_of_unique_sellers",
    "buy_perc", "sell_perc"
]

# ==============================================================================
# --- 🛠️ HELPER FUNCTIONS ---
# ==============================================================================

def get_redis_client():
    try:
        r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True)
        r.ping()
        return r
    except Exception as e:
        print(f"✗ Failed to connect to Redis: {e}")
        exit()

def fetch_all_pool_mappings(r_client):
    """Returns a dict: { pool_address: base_vault }"""
    print("⏳ Fetching pool mappings from Redis...")
    return r_client.hgetall(KEY_PAIR_TO_BASE)

def fetch_data_from_db(base_vault, num_timesteps):
    """
    Queries the first 'num_timesteps' rows for a specific Base Vault.
    Returns a DataFrame.
    """
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        # We LIMIT by num_timesteps to get only the first N minutes (intervals)
        query = f"""
            SELECT * FROM pool_master_5min
            WHERE poolIdentifier = '{base_vault}'
            ORDER BY time ASC
            LIMIT {num_timesteps};
        """
        df = pd.read_sql(query, conn)
        conn.close()
        return df
    except Exception as e:
        # print(f"⚠️ DB Error for {base_vault}: {e}")
        return None

def process_pool_data(df, num_timesteps):
    """
    Cleans, PADS, and converts DB DataFrame to Tensor.
    """
    if df is None or df.empty:
        return None

    # 1. Fill missing columns with 0 if DB schema drifted (safety)
    for col in FEATURE_ORDER:
        if col not in df.columns:
            df[col] = 0.0

    # 2. Select ordered features
    df_features = df[FEATURE_ORDER].fillna(0.0)

    # 3. PAD if length < num_timesteps
    # (Since we used LIMIT in SQL, it will never be > num_timesteps, only <=)
    current_len = len(df_features)
    if current_len < num_timesteps:
        # Create zero-padding DataFrame
        padding = pd.DataFrame(
            np.zeros((num_timesteps - current_len, len(FEATURE_ORDER))),
            columns=FEATURE_ORDER
        )
        df_features = pd.concat([df_features, padding], ignore_index=True)
    
    # 4. Convert to Tensor
    return torch.tensor(df_features.values.astype("float32"))

def save_tensors(tensors_list, output_path):
    if not tensors_list:
        print(f"⚠️ No data for {output_path}, skipping.")
        return
    
    final_tensor = torch.stack(tensors_list)
    torch.save(final_tensor, output_path)
    print(f"✅ Saved {final_tensor.shape} to {os.path.basename(output_path)}")

def save_column_order_json(output_dir):
    path = os.path.join(output_dir, "column_order.json")
    with open(path, 'w') as f:
        json.dump(FEATURE_ORDER, f, indent=4)
    print(f"✅ Saved column order to {path}")

# ==============================================================================
# --- 🚀 MAIN EXECUTION ---
# ==============================================================================
if __name__ == "__main__":
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    save_column_order_json(OUTPUT_DIR)

    # 1. Get Mappings
    r = get_redis_client()
    pool_map = fetch_all_pool_mappings(r) # {addr: vault}
    
    all_pools = list(pool_map.keys())
    
    # 2. Separate Safe vs. Rugs
    safe_vaults = []
    rug_vaults = []

    for addr, vault in pool_map.items():
        if addr in SAFE_POOL_ADDRESSES:
            safe_vaults.append(vault)
        else:
            rug_vaults.append(vault)

    print(f"🔍 Found {len(safe_vaults)} Safe Pools (defined by you).")
    print(f"🔍 Found {len(rug_vaults)} Potential Rug Pulls (rest).")

    # 3. Shuffle & Split Rug Pulls
    random.seed(RANDOM_SEED)
    random.shuffle(rug_vaults)
    
    split_idx = int(len(rug_vaults) * TRAIN_SET_SIZE_RUGS)
    train_rug_vaults = rug_vaults[:split_idx]
    test_rug_vaults = rug_vaults[split_idx:]

    print(f"   - Training Rugs: {len(train_rug_vaults)}")
    print(f"   - Testing Rugs:  {len(test_rug_vaults)}")

    # 4. Loop for 5, 10, 15 minutes (Seq Len 1, 2, 3)
    # Timestep 1 = 5 min, 2 = 10 min, 3 = 15 min
    for seq_len in [1, 2, 3]: 
        print(f"\n" + "="*50)
        print(f"### Processing SEQ_LEN = {seq_len} (First {seq_len*5} mins) ###")
        print("="*50)

        # --- Helper to process a list of vaults ---
        def process_list(vault_list, label_desc):
            tensors = []
            for vault in tqdm(vault_list, desc=f"Querying {label_desc}"):
                df = fetch_data_from_db(vault, seq_len)
                # Only keep if it has AT LEAST 1 row of data
                if df is not None and len(df) > 0:
                    t_data = process_pool_data(df, seq_len)
                    if t_data is not None:
                        tensors.append(t_data)
            return tensors

        # A. Train Positive (Rug Pulls)
        train_pos_tensors = process_list(train_rug_vaults, "Train Rugs")
        save_tensors(train_pos_tensors, os.path.join(OUTPUT_DIR, f"train_positive_{seq_len}.pt"))

        # B. Test Positive (Rug Pulls)
        test_pos_tensors = process_list(test_rug_vaults, "Test Rugs")
        save_tensors(test_pos_tensors, os.path.join(OUTPUT_DIR, f"test_positive_{seq_len}.pt"))

        # C. Test Negative (Safe Pools)
        test_neg_tensors = process_list(safe_vaults, "Safe Pools")
        save_tensors(test_neg_tensors, os.path.join(OUTPUT_DIR, f"test_negative_{seq_len}.pt"))

    print("\n🎉 Database extraction complete! You can now run the training script.")